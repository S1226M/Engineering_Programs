﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Pratice
{
    internal class Student
    {
        public int Rno { get; set; }
        public string Name { get; set; }
        public string Age { get; set; }
        public string Branch { get; set; }
        public float CPI { get; set; }  
        public int sem { get; set; }
    }
}

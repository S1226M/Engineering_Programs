﻿namespace Count_OF_Three_Demo.Models
{
    public class CountDemoModel
    {
        public int Total_Country { get; set; }
        public int Total_City { get; set; }
        public int Total_State { get; set; }
    }
}

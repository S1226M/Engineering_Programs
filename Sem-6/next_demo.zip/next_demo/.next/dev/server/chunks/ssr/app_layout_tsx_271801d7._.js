module.exports = [
"[project]/app/layout.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

const e = new Error("Could not parse module '[project]/app/layout.tsx'\n\nExpected ',', got 'children'");
e.code = 'MODULE_UNPARSABLE';
throw e;
}),
];
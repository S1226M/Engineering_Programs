module.exports = [
"[project]/.next-internal/server/app/(admin)/dashboard/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_dashboard_page_actions_adaad7cb.js.map
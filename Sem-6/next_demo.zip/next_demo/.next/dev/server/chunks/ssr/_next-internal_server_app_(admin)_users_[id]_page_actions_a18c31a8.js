module.exports = [
"[project]/.next-internal/server/app/(admin)/users/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_users_%5Bid%5D_page_actions_a18c31a8.js.map
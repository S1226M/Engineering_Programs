import Image from "next/image";
import Link from "next/link";

export default function Home() {
  return (
    // <div className="p-6 space-y-6">
    //   <h1 className="text-3xl font-bold">Dashboard</h1>

    //   <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
    //     <div className="bg-white shadow-md rounded-2xl p-6 border hover:shadow-lg transition">
    //       <h2 className="text-xl font-semibold mb-2">Total Users</h2>
    //       <p className="text-4xl font-bold">1,245</p>
    //       <p className="text-gray-500 text-sm">Updated just now</p>
    //     </div>

    //     <div className="bg-white shadow-md rounded-2xl p-6 border hover:shadow-lg transition">
    //       <h2 className="text-xl font-semibold mb-2">Active Sessions</h2>
    //       <p className="text-4xl font-bold">87</p>
    //       <p className="text-gray-500 text-sm">Past 24 hours</p>
    //     </div>

    //     <div className="bg-white shadow-md rounded-2xl p-6 border hover:shadow-lg transition">
    //       <h2 className="text-xl font-semibold mb-2">New Signups</h2>
    //       <p className="text-4xl font-bold">32</p>
    //       <p className="text-gray-500 text-sm">Today</p>
    //     </div>
    //   </div>

    //   <div>
    //     <h2 className="text-2xl font-semibold mb-4">Quick Actions</h2>
    //     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
    //       <Link href="/" className="bg-blue-600 text-white p-4 rounded-xl text-center hover:bg-blue-700 transition">
    //         Manage Users
    //       </Link>
    //       <Link href="/" className="bg-green-600 text-white p-4 rounded-xl text-center hover:bg-green-700 transition">
    //         View Reports
    //       </Link>
    //       <Link href="/" className="bg-purple-600 text-white p-4 rounded-xl text-center hover:bg-purple-700 transition">
    //         Settings
    //       </Link>
    //       <Link href="/" className="bg-orange-600 text-white p-4 rounded-xl text-center hover:bg-orange-700 transition">
    //         Analytics
    //       </Link>
    //     </div>
    //   </div>

    //   <div className="bg-white shadow-md rounded-2xl p-6 border">
    //     <h2 className="text-2xl font-semibold mb-4">Recent Activity</h2>
    //     <ul className="space-y-3">
    //       <li className="border-b pb-2">John Doe created a new account</li>
    //       <li className="border-b pb-2">System updated to version 1.2</li>
    //       <li className="border-b pb-2">3 users reported issues</li>
    //       <li>Admin logged in from dashboard</li>
    //     </ul>
    //   </div>

    //   <div className="bg-white shadow-md rounded-2xl p-6 border text-center text-gray-500">
    //     <p>📊 Analytics Chart</p>
    //   </div>
    // </div>
    <>
      <h1>hello</h1>
    </>
  );
}